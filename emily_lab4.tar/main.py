import os
import string
import psycopg2
from flask import Flask, request
app = Flask(__name__)
 
# @app.route("/")
# def hello_world():
#   name = os.environ.get("NAME", "World")
#   return "Hello {}".format(name)
 
@app.route('/gdd-7')
def get_gdd7():
    # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch geojson
    query = """
    ALTER TABLE gdd_bestmethod0
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326); 
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod0 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_string = response[0]
    return json_string
 
@app.route('/gdd-6')
def get_gdd6():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE gdd_bestmethod1
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod1 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_krig = response[0]
    return json_krig
 
@app.route('/gdd-5')
def get_gdd5():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE gdd_bestmethod2
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod2 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi

@app.route('/gdd-4')
def get_3daysago():
    # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch geojson
    query = """
    ALTER TABLE gdd_bestmethod3
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod3 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_string = response[0]
    return json_string
 
@app.route('/gdd-3')
def get_2daysago():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE gdd_bestmethod4
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod4 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_krig = response[0]
    return json_krig
 
@app.route('/gdd-2')
def get_yesterday():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE gdd_bestmethod5
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod5 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi
 
@app.route('/gdd-1')
def get_today():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE gdd_bestmethod3
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM gdd_bestmethod3 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi


# EVAPOTRANSPIRATION LAYERS:
@app.route('/et-7')
def get_et7():
    # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch geojson
    query = """
    ALTER TABLE et_bestmethod0
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod0 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_string = response[0]
    return json_string
 
@app.route('/et-6')
def get_et6():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE et_bestmethod1
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);    
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod1 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_krig = response[0]
    return json_krig
 
@app.route('/et-5')
def get_et5():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE et_bestmethod2
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);    
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod2 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi

@app.route('/et-4')
def get_3daysagoet():
    # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch geojson
    query = """
    ALTER TABLE et_bestmethod3
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod3 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_string = response[0]
    return json_string
 
@app.route('/et-3')
def get_2daysagoet():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE et_bestmethod4
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod4 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_krig = response[0]
    return json_krig
 
@app.route('/et-2')
def get_yesterdayet():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE et_bestmethod5
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
            SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod5 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi
 
@app.route('/et-1')
def get_todayet():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """
    ALTER TABLE et_bestmethod5
        ALTER COLUMN shape TYPE geometry(point, 4326)
            USING ST_SetSRID(shape,4326);
    SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM et_bestmethod5 as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi

# route only prints data to console
# @app.route('/print_data', methods=['POST'])
# def print_data():
#   print("*********************")
#   print("*********************")
#   print(request.method) # finds method -> here it should be "POST"
#   print(request.data) # generic - get all data; covers case where you don't know what's coming
#   print(request.json) # parses json data
#   print("*********************")
#   print("*********************")
#   return "Accepted 202 - post received; printed to console"
 
 
if __name__ == "__main__":
    app.run(debug = True, host = "0.0.0.0", port = int(os.environ.get("PORT", 8080)))
